﻿namespace dependency_inversion_after
{
    public interface IMessageSender
    {
        void Send(string number);
    }
}