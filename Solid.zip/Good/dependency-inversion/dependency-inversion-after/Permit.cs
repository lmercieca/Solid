﻿namespace dependency_inversion_after
{
    public class Permit
    {
        public string Number { get; set; }
    }
}
