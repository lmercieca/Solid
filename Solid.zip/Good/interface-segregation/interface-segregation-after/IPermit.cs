﻿namespace interface_segregation_after
{
    interface IPermit
    {
        Site Site { get; }
    }
}
