﻿namespace interface_segregation_after
{
    interface ICostPermit
    {
        int Cost();
    }
}
