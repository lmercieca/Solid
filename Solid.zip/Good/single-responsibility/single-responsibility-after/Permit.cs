﻿namespace single_responsibility_after
{
    public class Permit
    {
        public string Number { get; set; }
    }
}
