﻿namespace interface_segregation_after
{
    public class Site
    {
        public string Name { get; set; }

        public string Address { get; set; }
    }
}
