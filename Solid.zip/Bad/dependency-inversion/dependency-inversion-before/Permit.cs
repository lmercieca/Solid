﻿namespace dependency_inversion_before
{
    public class Permit
    {
        public string Number { get; set; }
    }
}
