﻿namespace liskov_substitution.Example_1
{ 
    public class Circle : Shape
    {
    }
}
