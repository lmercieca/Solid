﻿namespace liskov_substitution.Example_1
{
    public class Shape
    {
    }
}
