﻿namespace single_responsibility_before
{
    public class Permit
    {
        public string Number { get; set; }
    }
}
