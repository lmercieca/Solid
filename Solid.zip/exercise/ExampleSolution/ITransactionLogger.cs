﻿namespace ExampleSolution
{
    public interface ITransactionLogger
    {
        void Log(string transactionMessage);
    }
}
