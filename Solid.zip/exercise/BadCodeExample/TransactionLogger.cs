﻿using System;

namespace BadCodeExample
{
    public class TransactionLogger
    {
        public void Log(string transactionMessage)
        {
            Console.WriteLine(transactionMessage);
        }
    }
}
